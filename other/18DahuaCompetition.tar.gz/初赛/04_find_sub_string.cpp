/*************************************************************************
	> File Name: 04_find_sub_string.cpp
	> Author: jiexue
	> Mail: jiexuelc@163.com
	> Created Time: Sat 05 May 2018 09:54:53 AM CST
 ************************************************************************/

#include<iostream>
#include<string>
using namespace std;

int find_sub_string(const string& str1,const string& str2)
{
    int cnt=0;
    string::size_type loc = 0;
    while(1){
        loc = str1.find(str2,loc);
        if(loc == string::npos){
            return cnt;
        }else {
            cnt++;
            loc++;
        }
    }
    return cnt;
}

int main()
{
    int t;
    cin >> t;
    while (t--){
        string str1,str2;
        cin >> str1;
        cin >> str2;
        cout << find_sub_string(str1,str2) << endl;
    }
    return 0;
}

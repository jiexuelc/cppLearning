#include "stdio.h"
#define max(a,b) ((a)>(b)?(a):(b))

int calc(int *nums,int n){
    int a=0,b=0,i;
    for(i=0;i<n;i++){
        if(i%2 == 0){
            a = max(b,a+nums[i]);
        }else{
            b = max(a,b+nums[i]);
        }
    }
    return max(a,b);
}

int main(){
    int T,i,n,j;
    scanf("%d",&T);
    int res[T];
    for(i=0;i<T;i++){
        scanf("%d",&n);
        int nums[n];
        for(j=0;j<n;j++){
            scanf("%d",&nums[j]);
        }
        res[i] = calc(nums,n);
    }
    for(i=0;i<T;i++){
        printf("%d\n",res[i]);
    }
}
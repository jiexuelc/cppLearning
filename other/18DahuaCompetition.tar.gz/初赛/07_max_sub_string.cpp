/*************************************************************************
	> File Name: 07_max_sub_string.cpp
	> Author: jiexue
	> Mail: jiexuelc@163.com
	> Created Time: Sat 05 May 2018 09:54:53 AM CST
 ************************************************************************/

#include<iostream>
#include<string>
using namespace std;

int max_sub_string(string& str,int len)
{
    char min = str[0];
    for(int i=1; i<len; i++){
        if(min>str[i]) min = str[i];
    }
    for(int i=0; i<len; i++){
		if(str.find(min) == string::npos) return 0;
        else {
			if(str.find(min) != str.rfind(min)) return 0;
			min++;
		}
    }
    return len;
}

int main()
{
    int t;
    cin >> t;
    while (t--){
        string str;
        cin >> str;
        int len = str.length();
        for(int i=len; i>0; i--){
            for(int j=0; j< len-i+1; j++){
                string sub = str.substr(j,i);
                if(0 != max_sub_string(sub,i)){
                    cout << i << endl;
                    i = -1;
                    break;
                }
            }
        }
    }
    return 0;
}

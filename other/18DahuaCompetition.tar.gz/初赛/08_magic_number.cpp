/*************************************************************************
	> File Name: 08_magic_number.cpp.cpp
	> Author: jiexue
	> Mail: jiexuelc@163.com
	> Created Time: Sat 05 May 2018 09:54:53 AM CST
 ************************************************************************/

#include<iostream>
#include<string>
using namespace std;

int sum_bin(int num)
{
    int sum = 0;
    for(int i=1;i<18;i++){
        sum = sum+(1 & num);
        num = (num>>1);
    }
    return sum;
}

int sum_dec(int num)
{
    int sum = 0;
    while(num > 0){
        sum += num%10;
        num /=10;
    }
    return sum;
}

int main()
{
    int t;
    cin >> t;
    while (t--){
        int m;
        int cnt = 0;
        cin >> m;
        for(int i=0; i<=m; i++){            
            //cout << (sum_bin(i) == sum_dec(i)) << endl;
            /*if(sum_bin(i) == sum_dec(i)){
                cout << i << endl;
            }*/
            cnt += (sum_bin(i) == sum_dec(i));
        }
        cout << cnt << endl;
    }
    return 0;
}
